const time = document.querySelector('.time');
const date = document.querySelector('.date');
const day = document.querySelector('.day');

setInterval(() =>{
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months= ['January','February','March','April','May','June','July','August','September','October','November','December'];
    const outPut ={
        date : numZero( new Date().getDate() ),
        year : new Date().getFullYear(),
        month : numZero( months[new Date().getMonth()] ),
        day :  numZero( days[new Date().getDay()] ),
        hour :  numZero( new Date().getHours() ),
        minute :  numZero( new Date().getMinutes() ),
        second : numZero( new Date().getSeconds() ),
    }
    const showTime = `${outPut.hour}:${outPut.minute}:${outPut.second} <span>${amPm(outPut.hour)}</span>`;
    const showDate = `${outPut.date}, ${outPut.month}, ${outPut.year}`;
    date.innerHTML = showDate;
    time.innerHTML = showTime;
    day.innerHTML = outPut.day;
},1000);
function numZero (n = 0) {
    if(n<10){
        return `0${n}`
    }else return n 
}

function amPm(a){
   if(a>11){
       return "PM"
   } else return "AM"
}

function hours (h){
    if(h<12){
        return h - 12;
    }else if(h==0){
        return 12;
    }else return h
}